paper_version_Real-world-produceing-pseudo
produceing-pesudo-S3DIS-R-GCN+Non-local
produceing-pseudo-Shapnet-RGCN+Non-local 
分别为真实点云 S3dis shapnet数据集伪标签生成
数据集设置详见data.py