import torch
import numpy as np

def knn(x, k):
    '''
    get k nearest neighbors' indices for a single point cloud feature
    :param x:  x is point cloud feature, shape: [B, F, N]
    :param k:  k is the number of neighbors
    :return: KNN graph, shape: [B, N, k]
    '''      
    inner = -2*torch.matmul(x.transpose(2, 1), x)
    xx = torch.sum(x**2, dim=1, keepdim=True)
    pairwise_distance = -xx - inner - xx.transpose(2, 1)
 
    idx = pairwise_distance.topk(k=k, dim=-1)[1]   # (batch_size, num_points, k)
    return idx
    
    
def eigen_function(X,device):
    '''
    get eigen and eigenVector for a single point cloud neighbor feature
    :param X:  X is a Tensor, shape: [B, N, K, F]
    :return eigen: shape: [B, N, F]
    '''
    B, N, K, F = X.shape
    # X_tranpose [N,F,K] 
    X_tranpose = X.permute(0, 1, 3, 2)
    # high_dim_matrix [N, F, F]
    high_dim_matrix = torch.matmul(X_tranpose, X)

    high_dim_matrix = high_dim_matrix.cpu().detach().numpy()
    eigen, eigen_vec = np.linalg.eig(high_dim_matrix)
    eigen_vec = torch.Tensor(eigen_vec).to(device)
    eigen = torch.Tensor(eigen).to(device)

    return eigen, eigen_vec
    
    
def eigen_Graph(x, k=20, device = torch.device('cpu')):
    '''
    get eigen Graph for point cloud
    :param X: x is a Tensor, shape: [B, F, N]
    :param k: the number of neighbors
    :return feature: shape: [B, F, N]
    :retrun idx_EuclideanSpace: k nearest neighbors of Euclidean Space, shape[B, N, k]
    :retrun idx_EigenSpace: k nearest neighbors of Eigenvalue Space, shape[B, N, k]
    '''
    x = x.permute(0, 2, 1)
    #print("eigen graph input size ", x.size())
    batch_size = x.size(0)
    num_dims = x.size(1)
    num_points = x.size(2)

    x = x.view(batch_size, -1, num_points)

    # idx [batch_size, num_points, k]
    idx_EuclideanSpace = knn(x, k=k)   
    idx_EuclideanSpace = idx_EuclideanSpace + torch.arange(0, batch_size, device=device).view(-1, 1, 1)*num_points
    idx_EuclideanSpace = idx_EuclideanSpace.view(-1)
 

    x = x.transpose(2, 1).contiguous()# (batch_size, num_points, num_dims)  -> (batch_size*num_points, num_dims) #   batch_size * num_points * k + range(0, batch_size*num_points)
    feature = x.view(batch_size*num_points, -1)[idx_EuclideanSpace, :]
    feature = feature.view(batch_size, num_points, k, num_dims) 
    
    eigen,eigen_vec = eigen_function(feature-x.view(batch_size, num_points, 1, num_dims).repeat(1, 1, k, 1), device)
    eigen_vec = eigen_vec.reshape([batch_size, num_points, -1])

    # print(x.shape)
    # print(eigen.shape)
    # print(eigen_vec.shape)
    feature = torch.cat(( x, eigen, eigen_vec), dim=2)
    k_ei = k #int(k/2)
    idx_EigenSpace = knn(eigen.permute(0,2,1), k=k_ei)   # (batch_size, num_points, k)
    idx_EigenSpace = idx_EigenSpace + torch.arange(0, batch_size, device=device).view(-1, 1, 1)*num_points
    idx_EigenSpace = idx_EigenSpace.view(-1)
    #.permute(0,2,1)
    idx_eu = torch.tensor([idx_EuclideanSpace.cpu().numpy(), np.asarray(list(range(batch_size*num_points))).repeat(k)]).to(x.device)
    idx_ei = torch.tensor([idx_EigenSpace.cpu().numpy(), np.asarray(list(range(batch_size*num_points))).repeat(k_ei)]).to(x.device)
    return feature, idx_eu, idx_ei

# def eigen_graph(x, batch, k = 20):
#     """
#     api for pytorch-geometric
#     :input x :  x is a tensor, shape:[batch_size*num_points, num_features]
#     param k: the number of neighbors
#     :return feature: shape: [batch_size*num_points, num_features]
#     :return idx_EuclideanSpace: k nearest neighbors of Euclidean Space, shape[[B*N*K],[B*N*K]]
#     :return idx_EigenSpace: k nearest neighbors of Eigenvalue Space, shape[[B*N*K],[B*N*K]]
#     """
#     batch_size = batch.max().cpu().numpy() + 1
#     feature_nums = x.size(-1)
#     num_points = int(x.size(0)/batch_size)
#
#     #print(x.reshape(batch_size,num_points,feature_nums).permute(0,2,1))
#     feat , idx_eu, idx_ei = eigen_Graph(x.reshape(batch_size,num_points,feature_nums).permute(0,2,1),k)
#
#     idx_eu = torch.tensor([idx_eu.cpu().numpy(), np.asarray(list(range(x.size(0)))).repeat(k)]).to(x.device)
#     idx_ei = torch.tensor([idx_ei.cpu().numpy(), np.asarray(list(range(x.size(0)))).repeat(k)]).to(x.device)
#     return feat.view(x.size(0),-1), idx_eu, idx_ei
#
#
# def knn_dgcnn(x, k):
#     inner = -2*torch.matmul(x.transpose(2, 1), x)
#     xx = torch.sum(x**2, dim=1, keepdim=True)
#     pairwise_distance = -xx - inner - xx.transpose(2, 1)
#
#     idx = pairwise_distance.topk(k=k, dim=-1)[1]   # (batch_size, num_points, k)
#
#     idx_base = torch.arange(0, idx.size(0), device=device).view(-1, 1, 1)*idx.size(1)
#     idx = idx + idx_base
#     idx = idx.view(-1)
#     return idx
    
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
def draw_Point_Cloud(Points, Lables=None, axis=True, scale = 0.5,save_name = "default", **kags):

    x_axis = Points[:, 2]
    y_axis = Points[:, 0]
    z_axis = Points[:, 1]
    fig = plt.figure()
    ax = Axes3D(fig)

    ax.scatter(x_axis, y_axis, z_axis, c=Lables,s=scale)
    # 设置坐标轴显示以及旋转角度
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    ax.view_init(elev=25, azim=-180)
    if not axis:
        # 关闭显示坐标轴
        plt.axis('off')
    fig.show()
    plt.savefig( save_name + ".png")

if __name__ == '__main__':
    #import h5py
    #ff = h5py.File("data.h5",'r')
    #orgi_pos = ff["data"][:].astype("float32")
    import os.path as osp
    from torch_geometric.datasets import ShapeNet
    import torch_geometric.transforms as T
    #category = 'Airplane'
    #path = osp.join(osp.dirname(osp.realpath(__file__)), '..', 'data', 'ShapeNet')
    #pre_transform = T.NormalizeScale()
    #shapenet_dataset = ShapeNet(path, category, split='test', pre_transform=pre_transform)
    import h5py
    #data_file = h5py.File("../data/realworlddataset/main_split_hardest/train.h5","r")
    data_file = h5py.File("1%_train_processed.h5","r")
    dataset = data_file['data'][:]
    label = data_file['label'][:]
    mask = data_file['mask'][:]
    train_mask = data_file['train_mask'][:]
    pred_mask = data_file['pred_mask'][:]
    x = 7500
    while True:
        orgi_pos = dataset[int(x)]
        print(label[int(x)])
        mask_i = mask[int(x)]
        pred_mask_i = train_mask[int(x)]
        pred_mask_ii = pred_mask[int(x)]
        print(orgi_pos.shape)
        pos = torch.tensor(orgi_pos).float().unsqueeze(0)
        #pos = torch.cat([pos,pos], dim = 0)
        #pos = pos.permute(0, 2, 1)
        #x = x.unsqueeze(0).permute(0, 2, 1)
        feat, idx_eu, idx_ei = eigen_Graph(pos, 20)
        print(feat)
        print(idx_eu)
        print(idx_ei)

        print(feat.shape)
        print(idx_eu.shape)
        print(idx_ei.shape)
        point_i = np.random.randint(2048)
        color_label = ['gray']*orgi_pos.shape[0]
        scale = [15]*orgi_pos.shape[0]
        scale2 = [15]*orgi_pos.shape[0]
        for eu_neighboor in idx_eu[0][point_i*20:(point_i+1)*20]:
	        color_label[eu_neighboor] = 'tab:orange'
	        scale[eu_neighboor] = 45
        for ei_neighboor in idx_ei[0][point_i*20:(point_i+1)*20]:
	        color_label[ei_neighboor] = 'tab:green'
	        scale[ei_neighboor] = 45
        color_label[point_i] = 'tab:red'
        scale[point_i] = 120
        mask_label = ['gray' if i == -1 else 'blue' for i in mask_i]
        pred_mask_ii = ['gray' if i == -1 else 'blue' for i in pred_mask_ii]
        pred_mask_label = ['blue' if j and not i == -1 else "gray"  if j and i == -1 else 'lightblue' for j,i in zip(pred_mask_i,mask_i)]
        pred_mask_label_scale = [60 if j else 15 for j,i in zip(pred_mask_i,mask_i)]
        unlabel = ['lightblue']*2048
        draw_Point_Cloud(orgi_pos, Lables=unlabel, scale=scale2, axis=False, save_name="-1")
        draw_Point_Cloud(orgi_pos,Lables = pred_mask_label ,scale = pred_mask_label_scale, axis=False,save_name="0")
        draw_Point_Cloud(orgi_pos,Lables = pred_mask_ii , scale = scale2,axis=False,save_name="1")
        draw_Point_Cloud(orgi_pos,Lables = mask_label , scale = scale2,axis=False,save_name="2")
        draw_Point_Cloud(orgi_pos,Lables=color_label,scale=scale, axis=False,save_name="3")
        # output_data = np.concatenate([orgi_pos,
        #                               np.asarray(pred_mask_label).reshape(-1,1),
        #                               np.asarray(pred_mask_ii).reshape(-1,1),
        #                               np.asarray(mask_label).reshape(-1,1)], axis=1)
        #print(output_data.shape)
        #np.savetxt("view_Data.txt", output_data.astype(np.float))

        x = input()
    # k = 4
    # data = torch.randn(2,3,5).to('cuda')
    # pyg_data = data.permute(0,2,1).reshape(-1,data.size(1))
    # print(data)
    # print(pyg_data)
    # print(data.permute(0,2,1).shape)
    # batch = torch.tensor(list(range(0,data.size(0)))*data.size(-1)).view(-1,data.size(0)).t().flatten().to(device)
    # print(batch)
    #
    # idx_dgcnn = knn_dgcnn(data,k)
    # print(idx_dgcnn, idx_dgcnn.shape)
    # print(data[0])
    # feat , idx_eu, idx_ei = eigen_Graph(data,k)
    #
    # print(idx_eu)
    # print(idx_ei)
    # from torch_cluster import knn_graph
    #
    # knn_idx = knn_graph(pyg_data, k, batch, loop=True)
    # print("pyg knn : {}".format(knn_idx))
    #
    #
    # batch = batch
    # feature, idx_eu,idx_ei = eigen_graph(pyg_data,batch,k=k)
    #
    # print(idx_eu)
    # print(idx_ei)
    #
    # print(feat)
    # print(feature)
  
    
