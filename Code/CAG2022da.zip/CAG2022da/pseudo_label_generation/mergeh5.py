import h5py
import numpy as np
pseudo_file = h5py.File("testing_pseudo-labeling-realword_1014.h5", "r")
class_file = h5py.File("testing_pseudo-labeling-realworld_cls_1014.h5","r")
# class_file = h5py.File("..//data//realworlddataset//main_split_RS_50//train.h5",'r')

data_batchlist = []
for key in pseudo_file.keys():
	data_batchlist.append(pseudo_file[key][:].reshape(1,-1, pseudo_file[key][:].shape[-1]))
clsses = class_file['cls'][:]
print(clsses.shape)
# all pseudo data N*4096*13 9+1+1+1+1 vector + pred_seg + seg + train_mask + seletive_mask
print(len(data_batchlist))
print(data_batchlist[0].shape)
data_batches = np.concatenate(data_batchlist,0)
print(data_batches.shape)
points = data_batches[:,:,:3]
pred_mask = data_batches[:,:,3]
mask = data_batches[:,:,4]
train_mask = data_batches[:,:,5]
select_mask = data_batches[:,:,6]
pseudo_processed_file = h5py.File("train_processed_1014.h5", "w")
pseudo_processed_file.create_dataset("data", data = points, dtype =  'f4')
pseudo_processed_file.create_dataset("label", data = clsses, dtype = 'i4')
pseudo_processed_file.create_dataset("pred_mask", data = pred_mask, dtype = 'i4')
pseudo_processed_file.create_dataset("mask", data = mask, dtype='i4')
pseudo_processed_file.create_dataset("train_mask", data = train_mask, dtype = 'b')
pseudo_processed_file.create_dataset("select_mask", data = select_mask, dtype= 'b')

for key in pseudo_processed_file.keys():
	print(key)
	print(pseudo_processed_file[key][:].shape)
	print(pseudo_processed_file[key][:].dtype)
pseudo_file.close()
pseudo_processed_file.close()