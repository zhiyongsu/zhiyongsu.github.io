import os.path as osp
import argparse

import torch
import torch.nn.functional as F
#from torch_geometric.datasets import S3DIS #ShapeNet

from s3dis import S3DIS
from torch_geometric.data import Data
import torch_geometric.transforms as T
#from rgcn_conv import RGCNConv
from torch_geometric.nn import GCNConv, DynamicEdgeConv,knn_graph, EdgeConv, radius_graph, RGCNConv# noqa
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import random
#import h5py
import numpy as np
from collections import Counter
from tqdm import tqdm
from EigenGraph import eigen_Graph

random.seed(100)
torch.manual_seed(7)
np.random.seed(100)
from torch.nn import Sequential as Seq, Dropout, Linear as Lin,BatchNorm1d as BN
def MLP(channels, bias=True):
    return Seq(*[
        Seq(Lin(channels[i - 1], channels[i], bias=bias),BN(channels[i]),torch.nn.LeakyReLU(negative_slope=0.2),Lin(channels[i], channels[i], bias=bias))
        for i in range(1, len(channels))
    ])
class RelationGraphConvNet(torch.nn.Module):
    def __init__(self,num_points, k = 20,num_bases = 5):
        super(RelationGraphConvNet, self).__init__()
        self.conv1 = RGCNConv(point_features, 16, num_relations = num_points*20*2, num_bases = num_bases)
        self.conv2 = RGCNConv(16, num_classes, num_relations = num_points*20*2, num_bases = num_bases)
        self.reg_params = self.conv1.parameters()
        self.non_reg_params = self.conv2.parameters()
        self.k = k
        self.num_points = num_points;

    def forward(self):
        x = data.x
        ##############r-gcn
        x = F.relu(self.conv1(x, edge_index, edge_weight))
        x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_index, edge_weight)

        return F.log_softmax(x, dim=1)




def draw_Point_Cloud(Points, Lables=None, axis=True, save_name = "default", **kags):

    x_axis = Points[:, 1]
    y_axis = Points[:, 2]
    z_axis = Points[:, 0]
    fig = plt.figure()
    ax = Axes3D(fig)

    ax.scatter(x_axis, y_axis, z_axis, c=Lables)
    # 设置坐标轴显示以及旋转角度
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    ax.view_init(elev=25, azim=0)
    if not axis:
        # 关闭显示坐标轴
        plt.axis('off')

    plt.savefig( save_name + ".png")

def compute_mIoU(pred_label, gt_label, print_log = False):
    minl, maxl = np.min(gt_label), np.max(gt_label)
    ious = []
    for l in range(minl, maxl+1):
        I = np.sum(np.logical_and(pred_label == l, gt_label == l))
        U = np.sum(np.logical_or(pred_label == l, gt_label == l))
        if U == 0: iou = 1
        else: iou = float(I) / U
        ious.append(iou)
    if(print_log):
        print(ious)
    return np.mean(ious), ious
seg_classes = list(range(13))
parser = argparse.ArgumentParser()
parser.add_argument('--use_gdc', action='store_true',
                    help='Use GDC preprocessing.')
args = parser.parse_args()
###############prepar to render some sample############
all_pos_to_render = np.array([])
all_label_render = np.array([])

save2txt = open("result.txt", 'a+')
save2txt_log = open("logs.txt",'a+')
view_ = False

for test_area in [1,2,3,4,5,6]: #Which area to use for testing (1-6). (default: 6)
    groundTruth = []
    predLabel = []
    area = test_area # area which
    path = osp.join(osp.dirname(osp.realpath(__file__)), '..', 'data', 'S3DIS')
    pre_transform = T.NormalizeScale()
    #shapenet_dataset = ShapeNet(path, category, split='test', pre_transform=pre_transform)
    shapenet_dataset = S3DIS(path, test_area = area, train=False, pre_transform = pre_transform)
    original_raw_dataset = S3DIS(path, test_area=area, train=False)
    print(" dataset len " , len(shapenet_dataset))
    print(shapenet_dataset)
    shapnet_pcd = shapenet_dataset[0]
    print(shapnet_pcd)
    point_features = 3
    num_classes = 12+1
    print("seg classes: ",num_classes)

    def train():
        model.train()
        optimizer.zero_grad()
        F.nll_loss(model()[data.train_mask], data.y[data.train_mask]).backward()
        optimizer.step()


    @torch.no_grad()
    def test():
        model.eval()
        logits, accs = model(), []
        for _, mask in data('train_mask', 'test_mask'):
            pred = logits[mask].max(1)[1]
            acc = pred.eq(data.y[mask]).sum().item() / mask.sum().item()
            accs.append(acc)
        return accs,logits.max(1)[1]

    meanIoUs = []
    meanAcc = [] #len(shapenet_dataset)
    #test_i = 3456
    for dataseti in range(len(shapenet_dataset)):
        shapnet_pcd = shapenet_dataset[dataseti]
        #shapnet_pcd.y = shapnet_pcd.y - seg_classes[category][0]
        print(shapnet_pcd.y)
        numpoints  = shapnet_pcd.x.shape[0]
        print(shapnet_pcd.pos.shape, shapnet_pcd.x.shape)
        k = 20
        label_ratio = 0.1
        batch = torch.tensor([0]*numpoints)

        dic_label_idx = {}
        for idx, label in enumerate(shapnet_pcd.y.cpu().numpy()):
            if label not in dic_label_idx:
                dic_label_idx[label] = [idx]
            else:
                dic_label_idx[label].append(idx)

        traininglabelIndex = []
        for dic_key in dic_label_idx.keys():
            dic_key_list_len = len(dic_label_idx[dic_key])
            sample_idxs = int(dic_key_list_len * label_ratio)
            if (sample_idxs == 0):
                sample_idxs = 1
            idx2choose = np.random.choice(dic_key_list_len, sample_idxs, replace=False)
            dic_key_label = np.array(dic_label_idx[dic_key])[idx2choose]
            traininglabelIndex.extend(dic_key_label.tolist())

        train_mask, test_mask ,val_mask = [],[],[]
        for i in range(numpoints):
            if i in traininglabelIndex:
                train_mask.append(True)
                test_mask.append(False)
            else:
                train_mask.append(False)
                test_mask.append(True)
            val_mask.append(False)

        print("train mask count: " , Counter(train_mask)[True])
        print("test_mask mask count: " , Counter(test_mask)[True])

    ##################build  data###################


        mydata = Data(x = shapnet_pcd.pos)
        mydata.train_mask = torch.tensor(train_mask).bool();
        mydata.test_mask = torch.tensor(test_mask).bool();
        mydata.val_mask = torch.tensor(val_mask).bool();
        mydata.y = shapnet_pcd.y;
        data = mydata
        # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        device = 'cuda'
        data = data.to(device)
        batch = batch.to(device)

        # rgcn
        model = RelationGraphConvNet(numpoints,num_bases = 10).to(device)
        optimizer = torch.optim.Adam([
            dict(params=model.reg_params, weight_decay=5e-4),
            dict(params=model.non_reg_params, weight_decay=5e-4)
        ], lr=0.013)

        best_val_acc = test_acc = 0
        epoch = 60
        best_miou = 0.0
        # #########################set = 3 knn = 40， 20-> 0 20 ->1 #########################
        #
        # k = 40
        # edge_index = knn_graph(data.x, k, batch, loop=False).to(device)
        # edge_weight = torch.tensor(([0]*int(k / 2) + [1]*int(k / 2)) * numpoints).long().to(device)


        #################
        # x_, idx_eu, idx_ei = eigen_Graph(data.x.unsqueeze(0), k, device=device)
        # idx_radius = radius_graph(data.x, r = 0.1, batch = batch)
        #
        # edge_index = torch.cat([idx_ei, idx_eu, idx_radius], dim=1)
        # edge_weight_eu = [0] * len(idx_eu[0])
        # edge_weight_ei = [1] * len(idx_ei[0])
        # edge_weight_er = [1] * len(idx_radius[0])
        # edge_weight = torch.tensor(edge_weight_eu + (edge_weight_ei) + edge_weight_er).long().to(device)

        # #####radius + ei graph
        # x_, idx_eu, idx_ei = eigen_Graph(data.x.unsqueeze(0), k, device=device)
        # idx_radius = radius_graph(data.x, r = 0.1, batch = batch)
        # edge_index = torch.cat([idx_ei, idx_radius], dim=1)
        # edge_weight_ei = [0] * len(idx_ei[0])
        # edge_weight_er = [1] * len(idx_radius[0])
        # edge_weight = torch.tensor(edge_weight_ei + edge_weight_er).long().to(device)

        x_, idx_eu, idx_ei = eigen_Graph(data.x.unsqueeze(0), k, device=device)

        edge_index = torch.cat([idx_ei, idx_eu], dim=1)
        edge_weight_eu = [0] * len(idx_eu[0])
        edge_weight_ei = [1] * len(idx_ei[0])
        edge_weight = torch.tensor(edge_weight_eu + (edge_weight_ei) ).long().to(device)

        for epoch in tqdm(range(1, epoch+1),ascii = True):
            train()
        accs, pred = test()
        train_acc, tmp_test_acc = accs[0], accs[1]
        acc_log =  (" {} train acc: {:.5f} test acc: {:.5f}").format(dataseti, train_acc,tmp_test_acc)
        print(acc_log)
        curr_miou,_ = compute_mIoU(pred.cpu().numpy(), shapnet_pcd.y.cpu().numpy())
        groundTruth+= shapnet_pcd.y.cpu().numpy().tolist()
        predLabel += pred.cpu().numpy().tolist()
        print("mIoU : ", curr_miou)
        if(view_ == True):
            if (dataseti == 0):
                print("append 0");
                all_pos_to_render = (shapnet_pcd.x)[:,3:].cpu().numpy().copy()
                all_label_render = data.y.cpu().numpy().copy()  # +seg_classes[category][0]
            else:
                #pass
                print("append {}".format(dataseti))
                all_pos_to_render = np.concatenate(
                    [all_pos_to_render, (shapnet_pcd.x)[:,3:].cpu().numpy()] )  # [3*(j % 4) , 0, 6 * (int(j - (j%5 +1))/5)]
                all_label_render = np.concatenate([all_label_render, data.y.cpu().numpy()])

        #save2txt_log.write(acc_log)
        #save2txt_log.write(" mIoU : {:.5f} \n".format(curr_miou))
        meanIoUs.append(curr_miou)
        meanAcc.append(tmp_test_acc)

    #print(meanIoUs)
    sum = 0.0
    i = 0
    for iou in meanIoUs:
        sum += iou
        i+=1

    macc = 0.0
    for acc in meanAcc:
        macc += acc
   # saveGroundTruth = open("gtLabel.txt",'a+')
    #savePred = open("predLabel.txt",'a+')
    np.savetxt("pred"+str(test_area)+".txt", np.array(predLabel).astype(int), fmt='%i', delimiter=",")
    np.savetxt("ground"+str(test_area)+".txt", np.array(groundTruth).astype(int), fmt='%i', delimiter=",")
    miou,ious = compute_mIoU(np.array(predLabel), np.array(groundTruth),print_log=True)
    print("class ious meaniou meanacc : ", ious + [miou] + [macc/i])
    np.savetxt("class_mean_iou" + str(test_area) + ".txt", np.array(ious + [miou] + [macc/i] ).astype(float), fmt='%f', delimiter=",")
    print(" fake mean IoU : " , sum/i)
    print("mIou :", miou)
    print("mean acc: ", macc/i)
    #save2txt.write(category + " : {:.5f} \n".format(sum/i))

#print(all_label_render.shape)
#print(all_pos_to_render.shape)
if(view_):
    from view import view_points_labels
    print(all_pos_to_render.shape)
    print(all_label_render.shape)
    view_points_labels(all_pos_to_render, all_label_render)
save2txt.close()