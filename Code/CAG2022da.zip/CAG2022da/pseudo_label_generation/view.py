#coding=utf-8#
import open3d as o3d
import numpy as np

g_class2color = {'ceiling':	[0,255,0],
                 'floor':	[0,0,255],
                 'wall':	[0,255,255],
                 'beam':        [255,255,0],
                 'column':      [255,0,255],
                 'window':      [100,100,255],
                 'door':        [200,200,100],
                 'table':       [170,120,200],
                 'chair':       [255,0,0],
                 'sofa':        [200,100,100],
                 'bookcase':    [10,200,100],
                 'board':       [200,200,200],
                 'clutter':     [50,50,50]}

def mini_color_table(index, norm=True):
    colors = [
         [100/255,50/255,110/255],[1.000, 235/255, 100/255],[51/255,150/255,145/255],
        [137/255,32/255,46/255],[4/255,180/255,206/255],[135/255,147/255,63/255],
        [1.0000, 0.3800, 0.0100], [1.0000, 0.6600, 0.1400], [0.4980, 1.0000, 0.0000],
        [0.5765, 0.4392, 0.8588], [0.3600, 0.1400, 0.4300], [0.5600, 0.3700, 0.6000],
        [0.5000, 0.5400, 0.5300], [0.8900, 0.1500, 0.2100], [0.6400, 0.5800, 0.5000],

        [0.4980, 1.0000, 0.8314], [0.9412, 0.9725, 1.0000], [0.5412, 0.1686, 0.8863],


    ]

    assert index >= 0 and index < len(colors)
    color = colors[index]

    if not norm:
        color[0] *= 255
        color[1] *= 255
        color[2] *= 255

    return color


def view_points(points, colors=None):
    '''
    points: np.ndarray with shape (n, 3)
    colors: [r, g, b] or np.array with shape (n, 3)
    '''
    cloud = o3d.PointCloud()
    cloud.points = o3d.Vector3dVector(points)

    if colors is not None:
        if isinstance(colors, np.ndarray):
            cloud.colors = o3d.Vector3dVector(colors)
        else: cloud.paint_uniform_color(colors)

    o3d.draw_geometries([cloud])


def label2color(labels):
    '''
    labels: np.ndarray with shape (n, )
    colors(return): np.ndarray with shape (n, 3)
    '''
    num = labels.shape[0]
    colors = np.zeros((num, 3))

    minl, maxl = np.min(labels), np.max(labels)
    for l in range(minl, maxl + 1):
        colors[labels==l, :] = mini_color_table(l)

    return colors


def view_points_labels(points, labels):
    '''
    Assign points with colors by labels and view colored points.
    points: np.ndarray with shape (n, 3)
    labels: np.ndarray with shape (n, 1), dtype=np.int32
    '''
    assert points.shape[0] == labels.shape[0]
    colors = label2color(labels)
    view_points(points, colors)

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
def draw_Point_Cloud(Points, Lables=None, axis=True, scale = 0.5,save_name = "default",format = "eps", **kags):

    x_axis = Points[:, 2]
    y_axis = Points[:, 0]
    z_axis = Points[:, 1]
    fig = plt.figure(save_name)
    ax = Axes3D(fig)

    ax.scatter(x_axis, y_axis, z_axis, c=Lables,s=scale)
    # ������������ʾ�Լ���ת�Ƕ�
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    ax.view_init(elev=30, azim=-30)
    if not axis:
        # �ر���ʾ������
        plt.axis('off')
    fig.show(save_name)
    #plt.savefig( save_name + "." + format, dpi=600,format=format)


if __name__ == '__main__':


    # import os
    # dirname = "./bag-dgcnn-output/"
    # file_names = os.listdir(dirname)
    # print(file_names)
    # file_list = [os.path.join(dirname,file) for file in file_names]
    # print(file_list)
    # scale = [15]*2048
    # for file in file_list:
    #     data = np.genfromtxt(file,delimiter=',').reshape(2048,-1)
    #     print(data.shape)
    #     points = data[:,:3]
    #     gt_label = data[:,3].astype('int64')
    #     pred_label = data[:,4].astype('int64')
    #     data_file = file.split("/")[-1].split('.')[0]
    #     print(data_file)
    #     pred_label = ['gray' if i == 0 else 'blue' for i in pred_label]
    #     gt_label = ['gray' if i == 0 else 'blue' for i in gt_label]
    #     draw_Point_Cloud(points,Lables=pred_label,scale=scale,save_name = data_file+"_maskpred", axis=False)
    #     draw_Point_Cloud(points,Lables=gt_label,scale=scale,save_name = data_file + "_maskgt", axis=False)
    # input()