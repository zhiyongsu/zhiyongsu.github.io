import os
import sys
BASE_DIR = os.path.dirname(__file__)
sys.path.append(BASE_DIR)
sys.path.append(os.path.join(BASE_DIR, '../utils'))
import tensorflow as tf
import numpy as np
import tf_util
from pointnet_util import pointnet_sa_module, pointnet_fp_module

NUM_CLASSES = 15
BACKGROUND_CLASS = -1

def placeholder_inputs(batch_size, num_point):
    pointclouds_pl = tf.placeholder(tf.float32, shape=(batch_size, num_point, 3))
    labels_pl = tf.placeholder(tf.int32, shape=(batch_size))
    mask_pl = tf.placeholder(tf.int32, shape=(batch_size, num_point)) 
    train_mask_pl = tf.placeholder(tf.bool,
                                shape=(batch_size, num_point))
    select_mask_pl = tf.placeholder(tf.bool,
                                shape=(batch_size, num_point))   
    return pointclouds_pl, labels_pl, mask_pl, train_mask_pl, select_mask_pl


def get_model(point_cloud, is_training, bn_decay=None, num_class=NUM_CLASSES):
    """ Part segmentation PointNet, input is BxNx3 (XYZ) """
    batch_size = point_cloud.get_shape()[0].value
    num_point = point_cloud.get_shape()[1].value
    end_points = {}
    l0_xyz = tf.slice(point_cloud, [0,0,0], [-1,-1,3])
    l0_points = None

    # Set Abstraction layers
    l1_xyz, l1_points, l1_indices = pointnet_sa_module(l0_xyz, l0_points, npoint=512, radius=0.2, nsample=64, mlp=[64,64,128], mlp2=None, group_all=False, is_training=is_training, bn_decay=bn_decay, scope='layer1')
    l2_xyz, l2_points, l2_indices = pointnet_sa_module(l1_xyz, l1_points, npoint=128, radius=0.4, nsample=64, mlp=[128,128,256], mlp2=None, group_all=False, is_training=is_training, bn_decay=bn_decay, scope='layer2')
    l3_xyz, l3_points, l3_indices = pointnet_sa_module(l2_xyz, l2_points, npoint=None, radius=None, nsample=None, mlp=[256,512,1024], mlp2=None, group_all=True, is_training=is_training, bn_decay=bn_decay, scope='layer3')

    ###########CLASSIFICATION BRANCH
    # print(l3_xyz.shape)
    # print(l3_points.shape)
    net = tf.reshape(l3_points, [batch_size, -1])
    # print(net.shape)
    # print()
    net = tf_util.fully_connected(net, 512, bn=True, is_training=is_training, scope='fc1', bn_decay=bn_decay)
    net = tf_util.dropout(net, keep_prob=0.5, is_training=is_training, scope='dp1')
    net = tf_util.fully_connected(net, 256, bn=True, is_training=is_training, scope='fc2', bn_decay=bn_decay)

    # print("Classification feature vector")
    class_vector = tf.expand_dims(net, axis=1)
    # print(class_vector.shape)
    # print()
    net = tf_util.dropout(net, keep_prob=0.5, is_training=is_training, scope='dp2')
    class_pred = tf_util.fully_connected(net, num_class, activation_fn=None, scope='fc3')

    ###########SEGMENTATION BRANCH
    # Feature Propagation layers
    l3_points_concat = tf.concat([l3_points, class_vector], axis=2)

    # l2_points = pointnet_fp_module(l2_xyz, l3_xyz, l2_points, l3_points_concat, [256,256], is_training, bn_decay, scope='fa_layer1')
    l2_points = pointnet_fp_module(l2_xyz, l3_xyz, l2_points, class_vector, [256,256], is_training, bn_decay, scope='fa_layer1')
    l1_points = pointnet_fp_module(l1_xyz, l2_xyz, l1_points, l2_points, [256,128], is_training, bn_decay, scope='fa_layer2')
    l0_points = pointnet_fp_module(l0_xyz, l1_xyz, l0_points, l1_points, [128,128,128], is_training, bn_decay, scope='fa_layer3')

    # FC layers
    # print(l0_points.shape)
    net = tf_util.conv1d(l0_points, 128, 1, padding='VALID', bn=True, is_training=is_training, scope='seg_fc1', bn_decay=bn_decay)
    # print(net.shape)
    # print()
    end_points['feats'] = net 
    net = tf_util.dropout(net, keep_prob=0.5, is_training=is_training, scope='seg_dp1')
    seg_pred = tf_util.conv1d(net, 2, 1, padding='VALID', activation_fn=None, scope='seg_fc2')
    # print(seg_pred.shape)
    # exit()

    # print(class_pred.shape)
    # print(seg_pred.shape)
    # exit()

    return class_pred, seg_pred


# def get_loss(class_pred, seg_pred, gt_label, gt_mask, seg_weight = 0.5):
#     """ pred: BxNxC,
#         label: BxN, """
#     batch_size = gt_mask.shape[0]
#     num_point = gt_mask.shape[1]

#     loss = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=class_pred, labels=gt_label)
#     classify_loss = tf.reduce_mean(loss)

#     #mask loss
#     ###convert mask to binary mask
#     per_instance_seg_loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(logits=seg_pred, labels=gt_mask), axis=1)
#     seg_loss = tf.reduce_mean(per_instance_seg_loss)

#     total_loss = (1-seg_weight)*classify_loss + seg_weight*seg_loss
#     return total_loss, classify_loss, seg_loss

def symmetric_cross_entropy_loss(y_true, y_pred,alpha, beta):
    y_true = tf.reshape(y_true, [-1])
    y_true = tf.one_hot(y_true,2) 
    y_pred = tf.nn.softmax(y_pred)
    y_true = tf.cast(y_true,dtype=tf.float32)
    y_pred = tf.cast(y_pred,dtype=tf.float32)
    y_true_1 = y_true
    y_pred_1 = y_pred

    y_true_2 = y_true
    y_pred_2 = y_pred

    y_pred_1 = tf.clip_by_value(y_pred_1, 1e-7, 1.0)
    y_true_2 = tf.clip_by_value(y_true_2, 1e-2, 1.0)
    print(y_pred_1)
    print(y_true_1)
    print(y_pred_2)
    print(y_true_2)

    ce_loss = tf.reduce_mean(-tf.reduce_sum(y_true_1 * tf.log(y_pred_1), axis = -1))
    print(ce_loss)
    rce_loss = tf.reduce_mean(-tf.reduce_sum(y_pred_2 * tf.log(y_true_2), axis = -1))
    print(rce_loss)
    return alpha*ce_loss + beta*rce_loss


def get_loss(class_pred, seg_pred, gt_label, gt_mask, Seg_train_mask, Seg_select_mask,seg_weight = 0.5):
    """ pred: BxNxC,
        label: BxN, """
    batch_size = gt_mask.shape[0]
    num_point = gt_mask.shape[1]

    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=class_pred, labels=gt_label)
    classify_loss = tf.reduce_mean(loss)
    #mask loss
    ###convert mask to binary mask
    # all noisy mask use ce
    #seg_loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits( logits=seg_pred, labels=gt_mask))
    
    # all noisy knn agrement mask
    """
    seg_loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(
        logits=tf.boolean_mask(seg_pred, Seg_select_mask), 
        labels=tf.boolean_mask(gt_mask, Seg_select_mask)))
    """
    # all noisy mask use ce+rce
    #seg_loss = symmetric_cross_entropy_loss(gt_mask,tf.reshape(seg_pred,[-1,2]),0.01, 0.6)

    # only clean mask use ce
    seg_loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits( logits=tf.boolean_mask(seg_pred, Seg_train_mask), labels=tf.boolean_mask(gt_mask, Seg_train_mask)))
    

    # clean + 0.1 noisy all ce now ours
    
    """
    per_instance_seg_loss1 = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(
    logits=tf.boolean_mask(seg_pred, Seg_train_mask), 
    labels=tf.boolean_mask(gt_mask, Seg_train_mask)
    ))
    per_instance_seg_loss2 = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(
            logits= tf.boolean_mask(seg_pred, tf.math.logical_and(tf.math.logical_not(Seg_train_mask),Seg_select_mask)),
            labels = tf.boolean_mask(gt_mask, tf.math.logical_and(tf.math.logical_not(Seg_train_mask), Seg_select_mask))
            )
            )
  
    per_instance_seg_loss = per_instance_seg_loss1 + 0.0075* per_instance_seg_loss2
    seg_loss = tf.reduce_mean(per_instance_seg_loss) #tf.constant(0.0)#tf.reduce_mean(per_instance_seg_loss)
    """

    # clean + noisy ce , with out knn
    """
    per_instance_seg_loss1 = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(
    logits=tf.boolean_mask(seg_pred, Seg_train_mask), 
    labels=tf.boolean_mask(gt_mask, Seg_train_mask)
    ))
    per_instance_seg_loss2 = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(
            logits= tf.boolean_mask(seg_pred, tf.math.logical_not(Seg_train_mask)),
            labels = tf.boolean_mask(gt_mask, tf.math.logical_not(Seg_train_mask))
            )
            )
  
    per_instance_seg_loss = per_instance_seg_loss1 + 0.005 * per_instance_seg_loss2
    seg_loss = tf.reduce_mean(per_instance_seg_loss) #tf.constant(0.0)#tf.reduce_mean(per_instance_seg_loss)
    """
    
    # noisy learning ours
    """
    
    per_instance_seg_loss1 = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(
    logits=tf.boolean_mask(seg_pred, Seg_train_mask), 
    labels=tf.boolean_mask(gt_mask, Seg_train_mask)
    ))
    per_instance_seg_loss2 = symmetric_cross_entropy_loss(tf.boolean_mask(gt_mask, tf.math.logical_and(tf.math.logical_not(Seg_train_mask), Seg_select_mask)),
    tf.boolean_mask(seg_pred, tf.math.logical_and(tf.math.logical_not(Seg_train_mask),Seg_select_mask)),0.05,3)
  
    per_instance_seg_loss = per_instance_seg_loss1 + per_instance_seg_loss2
    seg_loss = tf.reduce_mean(per_instance_seg_loss) #tf.constant(0.0)#tf.reduce_mean(per_instance_seg_loss)
    """

    total_loss = (1-seg_weight)*classify_loss + seg_weight*seg_loss
   

    return total_loss, classify_loss, seg_loss



if __name__=='__main__':
    with tf.Graph().as_default():
        inputs = tf.zeros((32,2048,6))
        net, _ = get_model(inputs, tf.constant(True))
        print(net)
