## Utilility Functions for 3D Point Cloud Deep Learning

### visualization tool

    sh compile_render_balls_so.sh
    python show3d_balls.py
