#imroved VF2
Implement partial matching for large scale process plant model
modified from yaolili's implementation of VF2
 
#Usage
python run.py queryGraphFile graphFile  outputFile

eg: python run.py data/mygraphdb.data data/Q12.my result.txt

