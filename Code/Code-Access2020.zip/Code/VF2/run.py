# FILE:     run.py
# ROLE:     run vf.py

import os
import sys
import time
from vf import Vf

if __name__ == '__main__':
    if len(sys.argv) < 4:
        print ("sys.argv[1]: Graph file")
        print ("sys.argv[2]: subGraph file")
        print ("sys.argv[3]: output file")
        exit()
    
    start = time.clock()
    print ("time1: ", start)    
    output = open(sys.argv[3], 'w+')
    sys.stdout = output
    
    vf2 = Vf()   
    vf2.main(sys.argv[1], sys.argv[2])   
    
    end = time.clock()
    print ("time3: ", end)
    print ("time4: ", (end - start)/60)
    output.close()
