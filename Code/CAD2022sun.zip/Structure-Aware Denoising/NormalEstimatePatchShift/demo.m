% clear;
% addpath ('../toolbox/jjcao_io')
% addpath ('../toolbox/jjcao_point')
% path        = './noisy';%'./groundTruth/ply';
% fpath       =   fullfile(path, '*.ply');
% im_dir      =   dir(fpath);
% im_num      =   length(im_dir);
% for s=1:im_num
%     ptr = pcread(fullfile(path, im_dir(s).name));
%     P.pts = ptr.Location;
%     % pcd2off(filename);
%     % filePath = [filename '.off'];
%     % [P.pts, trueNormals] = read_noff(filePath);
%     [normals, knns, noncomputeCount] = normalEstimatePatchShift(P.pts, ptr); 
%     new_point_cloud = pointCloud(P.pts,'Normal',normals);
% %�ض���
%     viewPoint = [0 0 0];
%     point = new_point_cloud.Location;
%     newDirectionNormal = new_point_cloud.Normal;
%     temp =  bsxfun(@minus,new_point_cloud.Location,viewPoint);
%     temp1 = temp.*new_point_cloud.Normal;
%     direction = sum(temp1,2);%����0���⣬С��0����
%     for i=1:new_point_cloud.Count
%         if(direction(i)<0)
%             newDirectionNormal(i,:) = -newDirectionNormal(i,:);
%         end
%     end
%     pc_temp = pointCloud(point,'Normal',newDirectionNormal);
% %     pcwrite(pc_temp,[filename '_normal.pcd']);
%     pcwrite(pc_temp,[im_dir(s).name(1:end - size('.ply',2))  'comNormal' '.ply']);
% end

    clear;
    addpath ('./toolbox/jjcao_io')
    addpath ('./toolbox/jjcao_point')
     path        = '../noisy/level_0.01';%'../groundTruth/ply';
    fpath       =   fullfile(path, '*.ply');
    im_dir      =   dir(fpath);
    im_num      =   length(im_dir);
    knn_all     =   cell(1,im_num);
    for s=2:im_num
        ptr = pcread(fullfile(path, im_dir(s).name));
        P.pts = ptr.Location;
        % pcd2off(filename);
        % filePath = [filename '.off'];
        % [P.pts, trueNormals] = read_noff(filePath);
        knnNei = 80;
        knnPatch = 30;
        neiBuildMethod = 2;
        [normals, knns, noncomputeCount] = normalEstimatePatchShift(P.pts, ptr,knnNei, knnPatch, neiBuildMethod); %Ĭ�������СΪ80

        new_point_cloud = pointCloud(P.pts,'Normal',normals);
        %�ض���
        viewPoint = [0 0 0];
        point = new_point_cloud.Location;
        newDirectionNormal = new_point_cloud.Normal;
        temp =  bsxfun(@minus,new_point_cloud.Location,viewPoint);
        temp1 = temp.*new_point_cloud.Normal;
        direction = sum(temp1,2);%����0���⣬С��0����
        for i=1:new_point_cloud.Count
            if(direction(i)<0)
                newDirectionNormal(i,:) = -newDirectionNormal(i,:);
            end
        end
        pc_temp = pointCloud(point,'Normal',newDirectionNormal);
        knn_all{s} = knns;
    %     pcwrite(pc_temp,[filename '_normal.pcd']);
        pcwrite(pc_temp,[im_dir(s).name(1:end - size('.ply',2))  'compute_normal' '.ply']);
    end