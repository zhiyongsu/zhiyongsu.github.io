function [ can_nei ] = neiBuildGrowth( curPt )

global TP;
global neigh_matrix;
%global P;

sizeNei = 0;
can_nei = cell(TP.knnNei,1);
neighbors =  neigh_matrix(curPt,1:TP.knnNei);
for jj = 1:TP.knnNei 
    center = neighbors(jj);
    if ~isempty( find(neigh_matrix(center, 1:TP.knnNei) == curPt, 1) )
        %��ǰ����������ӵ�ĳ�ʼ������
        neis_nei = neiGrowth(center);%nei�ش���80%knnNei
        sizeNei = sizeNei + 1;
        can_nei{sizeNei} = neis_nei;        
    end
end
can_nei = can_nei(1:sizeNei);
end

