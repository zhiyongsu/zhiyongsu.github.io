function [model,llh,label] = Gmm(data,model,nlsp)
model.nvec    = size(data,2);
model.ndim    = size(data,1);
R = initialization(data,model.cls_num,nlsp);%��Ϊԭ��ʼ��
% label = [];%��¼ÿ�����������ĸ���
iter = model.iter;
tol = 1e-6;
llh = -inf(1,model.iter);
converged = false;
t = 1;
while ~converged && t < iter
    t = t+1;
    model = maximization(data,R,nlsp);
    clear R;
    [R, llh(t)] = expectation(data,model,nlsp);
    % output
    fprintf('Iteration %d of %d, logL: %.2f\n',t,iter,llh(t));
    % output
    [~,label(:)] = max(R,[],2);
    u = unique(label);   % non-empty components
    if size(R,2) ~= size(u,2)
        R = R(:,u);   % remove empty components
    else
        converged = llh(t)-llh(t-1) < tol*abs(llh(t));
    end
end

label=label';
model.R = R;
if converged
    fprintf('Converged in %d steps.\n',t-1);
else
    fprintf('Not converged in %d steps.\n',iter);
end



