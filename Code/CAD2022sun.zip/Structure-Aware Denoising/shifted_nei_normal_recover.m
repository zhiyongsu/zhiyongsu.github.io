%����Ӧ����ĵ����
function [shifted_result, ptr_TEST] = shifted_nei_normal_recover(ptr_std, ptr_noise, normals, search_size_update,Iterations,filename_noise, ite)

    addpath ('./NormalEstimatePatchShift')
    [knns] = compute_shifted_nei(ptr_noise);
  
    cloud_ptr_str = ptr_std; 
    cloud_ptr_noise = ptr_noise;
    count=cloud_ptr_noise.Count;
    location =cloud_ptr_noise.Location;
    ptr_TEST = cloud_ptr_noise;
    for ite_i =1:Iterations
        for i =1:count
            searchPoint = location(i,:);
            searchPoint_normal = normals(:,i);
            indices = knns{i};
            search_size_update = max(size(indices));
            ne_point = location(indices,:);
            ne_normal = normals(:,indices);
          %2020_CAD,n��������,n'n��3*3����
            alf = 1/(3*search_size_update);
            fac1 = bsxfun(@minus,ne_point, searchPoint);%�м����1
            temp=zeros(search_size_update,3);
            for k=1:search_size_update
                temp(k,:) = fac1(k,:)*(ne_normal(:,k)*ne_normal(:,k)' + searchPoint_normal*searchPoint_normal');
            end
            delta_p = alf*sum(temp);
            location(i,:) =  searchPoint+delta_p;
        end
        ptCloud = pointCloud(single(location(:,1:3)));
        ptr_TEST = pointCloud(ptCloud.Location,'Normal',normals');%����ͬʱ�洢��ɫ�ͷ�����Ϣ
        [dis_mean, dis_max, delta_mean, MSE ,SNR] = MSE_SNR_Evaluate_pointCloud(cloud_ptr_str,ptr_TEST);
        shifted_result(ite_i,:) = [dis_mean, dis_max, delta_mean, MSE ,SNR]
        pcwrite(ptr_TEST,[filename_noise num2str(eval('ite')) '_' num2str(eval('ite_i')) '.ply']);
    end


    %     [dis_mean, dis_max, delta_mean, MSE ,SNR]% = MSE_SNR_Evaluate_pointCloud(cloud_ptr_str,ptr_TEST);[dis_mean, dis_max, delta_mean, MSE ,SNR]
    
%     save('shifted_result','shifted_result');
end
