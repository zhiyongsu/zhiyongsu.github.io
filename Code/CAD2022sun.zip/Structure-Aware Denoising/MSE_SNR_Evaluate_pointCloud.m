
function[dis_mean, dis_max, delta_mean, MSE ,SNR] = MSE_SNR_Evaluate_pointCloud(ptr_standard,ptr_test)


%�ж��Ƿ��з���
ne_size = 10;
if isempty(ptr_standard.Normal)
  init_normals_standard = double(pcnormals(ptr_standard,ne_size));%�ڶ�������Ϊ��ʼ��������Ҫ����Ĵ�С 
else
  init_normals_standard = ptr_standard.Normal;  
end
if isempty(ptr_test.Normal)
  init_normals_test = double(pcnormals(ptr_test,ne_size));%�ڶ�������Ϊ��ʼ��������Ҫ����Ĵ�С 
else
  init_normals_test = ptr_test.Normal;  
end

dis1 = zeros(ptr_standard.Count,1);
dis2 = zeros(ptr_test.Count,1);

for i = 1:ptr_standard.Count
    searchPoint = ptr_standard.Location(i,:);
    [indice, ~] = findNearestNeighbors(ptr_test,searchPoint,1);%�ҵ������
    dis1_temp0 = ptr_test.Location(indice,:)-searchPoint;
    dis1(i) = sum(dis1_temp0.*dis1_temp0);
end
dis = 0;
for i = 1:ptr_test.Count
    searchPoint = ptr_test.Location(i,:);
    [indice, ~] = findNearestNeighbors(ptr_standard,searchPoint,1);%�ҵ������
    dis2_temp0 = ptr_standard.Location(indice,:)-searchPoint;
    dis2(i) = sum(dis2_temp0.*dis2_temp0);
    test_dis = sum(searchPoint.*searchPoint); %�������Ƶ�ƽ��
    dis = dis+test_dis;
end
MSE = mean(dis1)+mean(dis2);

SNR = 10*log10(dis/(ptr_test.Count * MSE));%�����
temp_point = double(ptr_test.Location - ptr_standard.Location);
temp_delta = abs(sum(double(init_normals_test .* init_normals_standard),2));

dis = sqrt(sum(temp_point.*temp_point,2));

W = sqrt(sum(init_normals_test .*init_normals_test,2)) .* sqrt(sum(init_normals_standard.*init_normals_standard,2));
dis_mean = mean(dis);
dis_max = max(dis);
delta_mean= mean(temp_delta./double(W));

return 
end
