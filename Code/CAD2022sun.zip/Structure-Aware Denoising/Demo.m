clear;
load GMM/point_cloud_npc_r_10x_win100_nlsp10_delta0.080_cls33.mat;
% dictionary and regularization parameter
par.D= GMM.D;
par.S = GMM.S;
par.IteNum = 3 ;  % the iteration number
par.ne_num = ne_num;  
% patch size
par.ch = 3;      %ÿ����������������ʾλ�ã�����
par.nlsp = nlsp;  % number of non-local patches
par.win = 100;    % size of window around the patch
par.En = 15  ;%ne_num*3
par.c1 = 0.01;%

n_path  = '.\Noisy';
gd_path = '.\GroundTruth';
n_path_temp      = fullfile(n_path, '*.ply');
gd_path_temp     = fullfile(gd_path, '*.ply');
n_pc_dir       = dir(n_path_temp);
gd_pc_dir      = dir(gd_path_temp);
pc_num         = length(n_pc_dir);
for s=1:pc_num
    %input str&noisy
    ptr_standard = pcread(fullfile(gd_path, gd_pc_dir(s).name));
    pc_noisy = pcread(fullfile(n_path, n_pc_dir(s).name));
    filename_noise = n_pc_dir(s).name(1:end-4);
%     t1=clock;
    [PCout,SNRn{s}]  =  Denoising_Guided(par,model,ptr_standard,pc_noisy,filename_noise);
    filename = sprintf('test_NPC_%dx_win%d_nlsp%d_delta%2.3f_cls%d.pcd',ne_num,win,nlsp,delta,cls_num);
    % pcwrite(PCout,filename);
%     t2=clock;
%     etime(t2,t1)
    %%
    ptr_test = PCout;
end

