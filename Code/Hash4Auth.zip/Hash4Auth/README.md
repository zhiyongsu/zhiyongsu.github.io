
#1.Data Preparation
    Generate two datasets of the test image: content-preserving samples and content-changing samples.

#2.Feature extraction
   Extract feature vectors of each sample through specified feature extraction methods.
   The feature descriptors used in the paper are derived from the following paper:

@ARTICLE{8360464, 
author={Z. {Tang} and L. {Chen} and X. {Zhang} and S. {Zhang}}, 
journal={IEEE Transactions on Knowledge and Data Engineering}, 
title={Robust Image Hashing with Tensor Decomposition}, 
year={2019}, 
volume={31}, 
number={3}, 
pages={549-560}, 
doi={10.1109/TKDE.2018.2837745}, 
ISSN={1041-4347}, 
month={March},}
 

#3.Hash Learning
   Learn the metric matrix and hash code for the test image based on its two datasets.
   'demo.m'

------------------------------------
Email:
su@njust.edu.cn