%Learn the metric matrix and hash code for the test image based on its two datasets.

load('data/datasets.mat');     %feature vectors of content-preserving samples and content-changing samples

L = WLMCC(xTr,yTr);                    %linear transformation

compression = 1;                       %compression ratio ?0 - 1     

Hash = MainHash(xTr,yTr,compression,L);       %Hash Code
